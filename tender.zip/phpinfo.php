<?php
echo  phpinfo();
