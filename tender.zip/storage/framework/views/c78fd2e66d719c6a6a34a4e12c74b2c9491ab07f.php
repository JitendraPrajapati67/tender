<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-6">

        <div class="card mx-4">
            <div class="card-body p-4">

                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <h1><?php echo e(trans('panel.site_title')); ?></h1>
                    <p class="text-muted"><?php echo e(trans('global.register')); ?></p>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-user fa-fw"></i>
                            </span>
                        </div>
                        <input type="text" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" required autofocus placeholder="<?php echo e(trans('global.user_name')); ?>" value="<?php echo e(old('name', null)); ?>">
                        <?php if($errors->has('name')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('name')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-envelope fa-fw"></i>
                            </span>
                        </div>
                        <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" required placeholder="<?php echo e(trans('global.login_email')); ?>" value="<?php echo e(old('email', null)); ?>">
                        <?php if($errors->has('email')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-lock fa-fw"></i>
                            </span>
                        </div>
                        <input type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" required placeholder="<?php echo e(trans('global.login_password')); ?>">
                        <?php if($errors->has('password')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('password')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="input-group mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-lock fa-fw"></i>
                            </span>
                        </div>
                        <input type="password" name="password_confirmation" class="form-control" required placeholder="<?php echo e(trans('global.login_password_confirmation')); ?>">
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-address-book fa-fw"></i>
                            </span>
                        </div>
                        <input type="number" name="mobile" class="form-control<?php echo e($errors->has('mobile') ? ' is-invalid' : ''); ?>" required placeholder="Enter mobile" value="<?php echo e(old('mobile', null)); ?>">
                        <?php if($errors->has('mobile')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('mobile')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-map-signs fa-fw"></i>
                            </span>
                        </div>
                        <input type="text" name="address" class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" required placeholder="Enter address" value="<?php echo e(old('address', null)); ?>">
                        <?php if($errors->has('address')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('address')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-user fa-fw"></i>
                            </span>
                        </div>
                        <input type="text" name="supplier_name" class="form-control<?php echo e($errors->has('supplier_name') ? ' is-invalid' : ''); ?>" required placeholder="Enter supplier name" value="<?php echo e(old('supplier_name', null)); ?>">
                        <?php if($errors->has('supplier_name')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('supplier_name')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-adjust fa-fw"></i>
                            </span>
                        </div>
                        <input type="text" name="company_reg_number" class="form-control<?php echo e($errors->has('company_reg_number') ? ' is-invalid' : ''); ?>" required placeholder="Enter company register number" value="<?php echo e(old('company_reg_number', null)); ?>">
                        <?php if($errors->has('company_reg_number')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('company_reg_number')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-map-signs fa-fw"></i>
                            </span>
                        </div>
                        <input type="text" name="company_contact_person" class="form-control<?php echo e($errors->has('company_contact_person') ? ' is-invalid' : ''); ?>" required placeholder="Enter company contact person" value="<?php echo e(old('company_contact_person', null)); ?>">
                        <?php if($errors->has('company_contact_person')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('company_contact_person')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <button class="btn btn-block btn-primary">
                        <?php echo e(trans('global.register')); ?>

                    </button>
                </form>

            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\tender\resources\views/auth/register.blade.php ENDPATH**/ ?>