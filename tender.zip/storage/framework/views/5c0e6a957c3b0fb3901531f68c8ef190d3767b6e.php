<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            Select users for invitation
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable datatable-TenderCategory">
                    <thead>
                    <tr>
                        <th width="10"></th>
                        <th>Sr No.</th>
                        <th>Name of company</th>
                        <th>Company registration number</th>
                        <th>Company contact person</th>
                        <th>Main email address</th>
                        <th>Mobile number</th>
                        <th>Company address</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($tender->id); ?>">
                            <td></td>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($tender->supplier_name ?? '-'); ?></td>
                            <td><?php echo e($tender->company_reg_number ?? '-'); ?></td>
                            <td><?php echo e($tender->company_contact_person ?? '-'); ?></td>
                            <td><?php echo e($tender->email ?? '-'); ?></td>
                            <td><?php echo e($tender->mobile ?? '-'); ?></td>
                            <td><?php echo e($tender->address ?? '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <form action="<?php echo e(route('admin.tender.invitation.send')); ?>" id="tenderSendForm" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tender_ids" value="<?php echo e($tenderIds); ?>">
                <input type="hidden" name="user_ids" value="">
            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script>
        $(function () {

            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

            let sendButtonText = 'Send Invitation'
            let sendButton = {
                text: sendButtonText,
                url: "<?php echo e(route('admin.tender.invitation.send')); ?>",
                className: 'btn-primary',
                action: function (e, dt, node, config) {
                    var ids = $.map(dt.rows({selected: true}).nodes(), function (entry) {
                        return $(entry).data('entry-id')
                    });

                    if (ids.length === 0) {
                        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')
                        return
                    }
                    // console.log(ids);
                    $("#tenderSendForm input[name=user_ids]").val(ids);
                    $("#tenderSendForm").submit();
                }
            }
            dtButtons.push(sendButton)


            $.extend(true, $.fn.dataTable.defaults, {
                orderCellsTop: true,
                order: [[1, 'asc']],
                pageLength: 10,
            });
            let table = $('.datatable-TenderCategory:not(.ajaxTable)').DataTable({buttons: dtButtons})
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function (e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

            let visibleColumnsIndexes = null;
            $('.datatable thead').on('input', '.search', function () {
                let strict = $(this).attr('strict') || false
                let value = strict && this.value ? "^" + this.value + "$" : this.value

                let index = $(this).parent().index()
                if (visibleColumnsIndexes !== null) {
                    index = visibleColumnsIndexes[index]
                }

                table.column(index).search(value, strict).draw()
            });
            table.on('column-visibility.dt', function (e, settings, column, state) {
                visibleColumnsIndexes = []
                table.columns(":visible").every(function (colIdx) {
                    visibleColumnsIndexes.push(colIdx);
                });
            })
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\tender\resources\views/admin/tenderInvitation/user.blade.php ENDPATH**/ ?>