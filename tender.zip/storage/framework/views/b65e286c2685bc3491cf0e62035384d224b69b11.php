
<?php $__env->startSection('content'); ?>


<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.tenderManagement.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.tender-categories.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.tender_reference_no')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->tender_reference_no); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.tender_title')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->tender_title); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.description')); ?>

                        </th>
                        <td>
                             <?php echo e($tender->description?? '-'); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.open_date')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->open_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.close_date')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->close_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.status')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->status); ?>

                        </td>
                    </tr>
                     <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.type')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->type); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.created_by')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->created_by); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class='form-group'>
                <?php $__currentLoopData = $tenderMapDocument; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="btn btn-default btn-sm"><i class="fa fa-download"></i> <?php echo e($label->document_orignal_name); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.bidManagement.title')); ?>

    </div>

    <div class="card-body">
        <form method="POST" id='bid-from' action="<?php echo e(route("bid.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="price"><?php echo e(trans('cruds.bidManagement.fields.price')); ?></label>
                <input onkeypress="return blockSpecialChar(event)"  class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" type="text" name="price" id="price" value="<?php echo e(old('price', '')); ?>" required>
                <?php if($errors->has('price')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('price')); ?>

                    </div>
                <?php endif; ?>
            </div>            
            <div class="form-group">
                <label class="required" for="discription"><?php echo e(trans('cruds.bidManagement.fields.description')); ?> <?php echo e(trans('cruds.tenderManagement.fields.description_helper')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('discription') ? 'is-invalid' : ''); ?>" type="text" name="discription" id="discription"  required></textarea>
                <?php if($errors->has('discription')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('discription')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                
                <input type='hidden' value='<?php echo e($tender->id); ?>' id='tender_id' name='tender_id'>
                
                <label class="required" for="document"><?php echo e(trans('cruds.bidManagement.fields.document')); ?></label>    
                <br>
                <input class=" <?php echo e($errors->has('document') ? 'is-invalid' : ''); ?>" type="file" name="document[]" id="document" multiple="multiple" value="" required>
               <a style="color:white;display:none;" class="btn btn-xs btn-danger remove  " >Remove</a>
                <?php if($errors->has('document')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('document')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class='filediv'>
            </div>
            <div class="form-group">   
             <button class="btn btn-sm btn-danger  add_more ">Add More Files</button>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script type="text/javascript">
function blockSpecialChar(e) {
var k = e.keyCode;
return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8   || (k >= 48 && k <= 57));
}
   var filecount= 1;
   $(document).ready(function() {
    $("#document").change(function () {
        var fileExtension = ['docx', 'xml', 'doc', 'pdf'];
        if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
            
            swal({
            title: '',
            text: "Only formats are allowed : "+fileExtension.join(', '),
            icon: "warning",
            buttons: true,
            dangerMode: true,
          });
        $(this).val("");
        }
    });
    $("#bid-from").validate();

    $(document).on('click','.remove',function(e){
        filecount--;
        if(filecount  < 2){
            $('.remove').hide();
        }
        $(this).closest('div').remove();
        
    });
    $('.add_more').click(function(e){
        filecount++;
        if(filecount  > 1){
            $('.remove').show();
        }
        e.preventDefault();
        $('.filediv').append('<div class="form-group"><input class="" type="file" name="document[]" id="document"  value="" required><a style="color:white;" class="btn btn-xs btn-danger remove ">Remove</a></div>');
        
    });
});
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Vivek_Project\tender\tender25\resources\views/bid/create.blade.php ENDPATH**/ ?>