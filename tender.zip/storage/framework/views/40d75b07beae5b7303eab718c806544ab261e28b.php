<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card mx-4">
            <div class="card-body p-4">
                <h1><?php echo e(trans('panel.site_title')); ?></h1>

                <p class="text-muted"><?php echo e(trans('global.login')); ?></p>

                <?php echo $__env->make('partials.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if(session('message')): ?>
                    <div class="alert alert-info" role="alert">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-user"></i>
                            </span>
                        </div>

                        <input id="mobile" name="mobile" type="text" class="form-control<?php echo e($errors->has('mobile') ? ' is-invalid' : ''); ?>" required autocomplete="mobile" autofocus placeholder="Enter mobile number" value="<?php echo e(old('mobile', null)); ?>">

                        <?php if($errors->has('mobile')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('mobile')); ?>

                            </div>
                        <?php endif; ?>
                    </div>


                    <div class="row">
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary px-4">
                                <?php echo e(trans('global.login')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\tender\resources\views/auth//otp/login.blade.php ENDPATH**/ ?>