
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.tenderManagement.title_singular')); ?>

    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.tender.update", [$tender->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="tender_reference_no"><?php echo e(trans('cruds.tenderManagement.fields.tender_reference_no')); ?></label>
                <input onkeypress="return blockSpecialChar(event)" class="form-control <?php echo e($errors->has('tender_reference_no') ? 'is-invalid' : ''); ?>" type="text" name="tender_reference_no" id="tender_reference_no"  value="<?php echo e(old('tender_reference_no', $tender->tender_reference_no)); ?>"  required>
                <?php if($errors->has('tender_reference_no')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tender_reference_no')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required" for="category_code"><?php echo e(trans('cruds.tenderManagement.fields.tender_title')); ?></label>
                <input onkeypress="return blockSpecialChar(event)" class="form-control <?php echo e($errors->has('tender_title') ? 'is-invalid' : ''); ?>" type="text" name="tender_title" id="tender_title"  value="<?php echo e(old('tender_title', $tender->tender_title)); ?>"  required>
                <?php if($errors->has('tender_title')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tender_title')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label class="required" for="tender_discription"><?php echo e(trans('cruds.tenderManagement.fields.description')); ?> <?php echo e(trans('cruds.tenderManagement.fields.description_helper')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('tender_discription') ? 'is-invalid' : ''); ?>" name="tender_discription" id="tender_discription"   required>
                <?php echo e(old('tender_discription', $tender->tender_discription)); ?>

                </textarea>
                <?php if($errors->has('tender_discription')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tender_discription')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required" for="open_date"><?php echo e(trans('cruds.tenderManagement.fields.open_date')); ?> </label>
                <input onkeypress="return blockSpecialChar(event)" class="form-control open_date <?php echo e($errors->has('open_date') ? 'is-invalid' : ''); ?>" type="text" name="open_date" id="open_date"  value="<?php echo e(old('open_date', $tender->open_date)); ?>"  required>
                <?php if($errors->has('open_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('open_date')); ?>

                    </div>
                <?php endif; ?>
               
            </div>


            <div class="form-group">
                <label class="required" for="close_date"><?php echo e(trans('cruds.tenderManagement.fields.close_date')); ?></label>
                <input onkeypress="return blockSpecialChar(event)" class="form-control close_date <?php echo e($errors->has('close_date') ? 'is-invalid' : ''); ?>" type="text" name="close_date" id="close_date" value="<?php echo e(old('close_date', $tender->close_date)); ?>" required>
                <?php if($errors->has('close_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('close_date')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            
            <div class="form-group">
                <label class=""><?php echo e(trans('cruds.tenderManagement.fields.category_name')); ?></label>
                <select class="form-control <?php echo e($errors->has('category_id') ? 'is-invalid' : ''); ?>" name="category_id" id="category_id" >
                    <option value disabled <?php echo e(old('category_id', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                   
                    <?php $__currentLoopData = $tenderCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <option value="<?php echo e($label->id); ?>" <?php echo e(old('category_id', '') === (string) $label->id ? 'selected' : ''); ?>><?php echo e($label->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('parent_id')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('parent_id')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            
            <?php $__currentLoopData = $material_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <label class=""><?php echo e($key); ?> :- </label>

                    <?php $__currentLoopData = $label; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $label2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <input style='margin-left: 5px;' value='<?php echo e($label2['id']); ?>' class="form-check-input" type="checkbox" name="material[]" id="material" />
                        <label class="" style="margin-left: 25px;"><?php echo e($label2['category_name']); ?></label> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </br>
                
            </br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="form-group">
                <label class=""><?php echo e(trans('cruds.tenderManagement.fields.status')); ?></label>
                <select class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status" id="status" >
                    <option value="0">Deactive</option>
                    <option value="1">Active</option>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required" for="type"><?php echo e(trans('cruds.tenderManagement.fields.type')); ?></label>
                 <select class="form-control <?php echo e($errors->has('type') ? 'is-invalid' : ''); ?>" name="type" id="type" >
                    <option value="0">Free</option>
                    <option value="1">Paid</option>
                </select>
            </div>
            <div class='form-group'>
                <?php $__currentLoopData = $tenderdocument; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label><?php echo e($label->document_orignal_name); ?></label> <a style="color:white;" id='<?php echo e($label->id); ?>' class="btn btn-xs btn-danger remove-doc">Remove</a></br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="form-group">
                <label class="required" for="document"><?php echo e(trans('cruds.tenderManagement.fields.document')); ?> </label>
                
                <br>
                <input class=" <?php echo e($errors->has('document') ? 'is-invalid' : ''); ?>" type="file" name="document[]" id="document" multiple="multiple" value="" >
                <a style="color:white;display:none;" class="btn btn-xs btn-danger remove  " >Remove</a>
                
                <?php if($errors->has('document')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('document')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class='filediv'>
            </div>
            <div class="form-group">   
             <button class="btn btn-sm btn-danger  add_more ">Add More Files</button>
            </div>
            <div class="form-group">
                <input type='hidden' value='<?php echo e($tender->id); ?>' name='tender_id'> 
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script type="text/javascript">
function blockSpecialChar(e) {
var k = e.keyCode;
return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8   || (k >= 48 && k <= 57));
}
var filecount= 1;
$(document).ready(function() {
$(document).on('click','.remove',function(e){
    filecount--;
    if(filecount  < 2){
        $('.remove').hide();
    }
    $(this).closest('div').remove();
    
});
$(".remove-doc").click(function(event){
      event.preventDefault();
      var id = $(this).attr('id');
      
      swal({
        title: '',
        text: '<?php echo e(trans('global.areYouSure')); ?>',
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
                $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: "<?php echo e(route('admin.tender.destroyDocument')); ?>",
          data: { id: id, _method: 'DELETE' }})
          .done(function () { 
            location.reload() 
        })

        } 
      });
  });
$('.add_more').click(function(e){
    filecount++;
    if(filecount  > 1){
        $('.remove').show();
    }
    e.preventDefault();
    $('.filediv').append('<div class="form-group"><input class="" type="file" name="document[]" id="document"  value="" required><a style="color:white;" class="btn btn-xs btn-danger remove ">Remove</a></div>');
});
$('#material_name').on('change', function(){
    $('.material_div').html('');
    $('.material_div').removeClass('hide');
    var id = $(this).val();       
    var material='';
    $.each(sites, function(key,val) {
        if(id==val.parent){
            material+='<div class="form-check"><input class="form-check-input" type="checkbox" name="material[]" id="material" value="'+val.id+'"><label class="form-check-label" for="material">'+val.category_name+'</label></div>';
        }
    });
    $('.material_div').html(material);
});
$('.open_date').datetimepicker({
    format: 'YYYY-MM-DD',
    locale: 'en',
    icons: {
      up: 'fas fa-chevron-up',
      down: 'fas fa-chevron-down',
      previous: 'fas fa-chevron-left',
      next: 'fas fa-chevron-right'
    }
  })

$('.close_date').datetimepicker({
    format: 'YYYY-MM-DD',
    locale: 'en',
    icons: {
      up: 'fas fa-chevron-up',
      down: 'fas fa-chevron-down',
      previous: 'fas fa-chevron-left',
      next: 'fas fa-chevron-right'
    }
  })
  $('.close_date').datetimepicker({format: 'yyyy-mm-dd hh:mm'});
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Vivek_Project\tender\tender25\resources\views/admin/tenderManagers/edit.blade.php ENDPATH**/ ?>