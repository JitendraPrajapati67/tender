
<?php $__env->startSection('content'); ?>


<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.tenderManagement.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.tender-categories.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.tender_reference_no')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->tender_reference_no); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.tender_title')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->tender_title); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.description')); ?>

                        </th>
                        <td>
                             <?php echo e($tender->description?? '-'); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.open_date')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->open_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.close_date')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->close_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.status')); ?>

                        </th>
                        <td>
                            <?php if($tender->status == 0): ?>
                              Inactive
                            <?php else: ?>
                              Active
                            <?php endif; ?>
                            
                        </td>
                    </tr>
                     <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.type')); ?>

                        </th>
                        <td>
                            <?php if($tender->type ==0): ?>
                                Free
                            <?php else: ?>
                                Paid
                            <?php endif; ?>
                            
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.created_by')); ?>

                        </th>
                        <td>
                            <?php if($tender->created_by == 1): ?>
                                Admin
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class='form-group'>
            <label class="" style="margin-left: 25px;">Materials:-</label>  
              <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="" style="margin-left: 25px;"><?php echo e($label->category_name); ?></label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </div>
            <div class='form-group'>
                <?php $__currentLoopData = $tenderMapDocument; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="btn btn-default btn-sm"><i class="fa fa-download"></i> <?php echo e($label->document_orignal_name); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.bidManagement.title')); ?>

    </div>

    <div class="card-body">
         <form method="POST" action="<?php echo e(route("bid.update", [$Bid->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="price"><?php echo e(trans('cruds.bidManagement.fields.price')); ?></label>
                <input onkeypress="return blockSpecialChar(event)"  class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" type="text" name="price" id="price" value="<?php echo e(old('price', $Bid->price )); ?>" required>
                <?php if($errors->has('price')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('price')); ?>

                    </div>
                <?php endif; ?>
            </div>            
            <div class="form-group">
                <label class="required" for="discription"><?php echo e(trans('cruds.bidManagement.fields.description')); ?> <?php echo e(trans('cruds.tenderManagement.fields.description_helper')); ?></label>
                <input class="form-control <?php echo e($errors->has('discription') ? 'is-invalid' : ''); ?>" type="text" name="discription" id="discription" value="<?php echo e(old('discription', $Bid->discription)); ?>" required>
                <?php if($errors->has('discription')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('discription')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class='form-group'>
                <?php $__currentLoopData = $tenderdocument; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label><?php echo e($label->document_orignal_name); ?></label> <a style="color:white;" id='<?php echo e($label->id); ?>' class="btn btn-xs btn-danger remove-doc">Remove</a></br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="form-group">
                <input type='hidden' value='<?php echo e($Bid->tender_id); ?>' id='tender_id' name='tender_id'>
                <input type='hidden' value='<?php echo e($Bid->bidder_id); ?>' id='bidder_id' name='bidder_id'>
                <input type='hidden' value='<?php echo e($Bid->id); ?>' id='id' name='id'> 
                
                <label class="required" for="document"><?php echo e(trans('cruds.bidManagement.fields.document')); ?></label>    
                <br>
                <input class=" <?php echo e($errors->has('document') ? 'is-invalid' : ''); ?>" type="file" name="document[]" id="document" multiple="multiple" value="" >
               <a style="color:white;display:none;" class="btn btn-xs btn-danger remove  " >Remove</a>
                <?php if($errors->has('document')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('document')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class='filediv'>
            </div>
            <div class="form-group">   
             <button class="btn btn-sm btn-danger  add_more ">Add More Files</button>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script type="text/javascript">
   function blockSpecialChar(e) {
var k = e.keyCode;
return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8   || (k >= 48 && k <= 57));
}

   var filecount= 1;
   $(document).ready(function() {
    $(document).on('click','.remove',function(e){
        filecount--;
        if(filecount  < 2){
            $('.remove').hide();
        }
        $(this).closest('div').remove();
        
    });
    $('.add_more').click(function(e){
        filecount++;
        if(filecount  > 1){
            $('.remove').show();
        }
        e.preventDefault();
        $('.filediv').append('<div class="form-group"><input class="" type="file" name="document[]" id="document"  value="" required><a style="color:white;" class="btn btn-xs btn-danger remove ">Remove</a></div>');
        
    });
    $(".remove-doc").click(function(event){
      event.preventDefault();
      var id = $(this).attr('id');
      
            
      swal({
        title: '',
        text: '<?php echo e(trans('global.areYouSure')); ?>',
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
            $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: "<?php echo e(route('admin.tender.destroyDocument')); ?>",
          data: { id: id, _method: 'DELETE' }})
          .done(function () { 
            location.reload() 
        });


        } 
      });
  });
});
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tender\resources\views/bid/edit.blade.php ENDPATH**/ ?>