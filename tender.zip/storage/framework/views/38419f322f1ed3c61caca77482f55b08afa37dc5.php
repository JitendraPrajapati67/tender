<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            Tender Invitation List
        </div>

        <div class="card-body">
            <?php echo $__env->make('partials.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable datatable-TenderCategory">
                    <thead>
                    <tr>
                        <th width="10"></th>
                        <th>Sr No.</th>
                        <th><?php echo e(trans('cruds.tenderManagement.fields.tender_title')); ?></th>
                        <th><?php echo e(trans('cruds.tenderManagement.fields.datetime')); ?></th>
                        <th><?php echo e(trans('cruds.tenderManagement.fields.status')); ?></th>
                        <th>Tender Type</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $tender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($tender->id); ?>">
                            <td></td>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($tender->tender_title ?? '-'); ?></td>
                            <td>
                                Open:-<?php echo e(date('Y-m-d', strtotime($tender->open_date)) ?? ''); ?>

                                Close:- <?php echo e(date('Y-m-d', strtotime($tender->close_date)) ?? ''); ?>

                            </td>
                            <td>
                                <?php if( date('Y-m-d') < date('Y-m-d', strtotime($tender->close_date)) ): ?>
                                    Open
                                <?php else: ?>
                                    Close
                                <?php endif; ?>
                            </td>
                            <td><?php if($tender->type==0): ?> Free <?php else: ?> Paid <?php endif; ?> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <form action="<?php echo e(route('admin.tender.invitation.users')); ?>" id="tenderForm" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tender_ids" value="">
            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script>
        $(function () {

            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tender_invitation')): ?>
            let sendButtonText = 'Send Invitation'
            let sendButton = {
                text: sendButtonText,
                url: "<?php echo e(route('admin.tender.invitation.users')); ?>",
                className: 'btn-primary',
                action: function (e, dt, node, config) {
                    var ids = $.map(dt.rows({selected: true}).nodes(), function (entry) {
                        return $(entry).data('entry-id')
                    });

                    if (ids.length === 0) {
                        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')
                        return
                    }
                    // console.log(ids);
                    $("#tenderForm input[name=tender_ids]").val(ids);
                    $("#tenderForm").submit();
                    // $.ajax({
                    //     headers: {'x-csrf-token': _token},
                    //     method: 'POST',
                    //     url: config.url,
                    //     data: {ids: ids, _method: 'POST'}
                    // }).done(function () {
                    //     location.reload()
                    // })

                }
            }
            dtButtons.push(sendButton)
            <?php endif; ?>

            $.extend(true, $.fn.dataTable.defaults, {
                orderCellsTop: true,
                order: [[1, 'asc']],
                pageLength: 10,
            });
            let table = $('.datatable-TenderCategory:not(.ajaxTable)').DataTable({buttons: dtButtons})
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function (e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

            let visibleColumnsIndexes = null;
            $('.datatable thead').on('input', '.search', function () {
                let strict = $(this).attr('strict') || false
                let value = strict && this.value ? "^" + this.value + "$" : this.value

                let index = $(this).parent().index()
                if (visibleColumnsIndexes !== null) {
                    index = visibleColumnsIndexes[index]
                }

                table
                    .column(index)
                    .search(value, strict)
                    .draw()
            });
            table.on('column-visibility.dt', function (e, settings, column, state) {
                visibleColumnsIndexes = []
                table.columns(":visible").every(function (colIdx) {
                    visibleColumnsIndexes.push(colIdx);
                });
            })
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\tender\resources\views/admin/tenderInvitation/index.blade.php ENDPATH**/ ?>