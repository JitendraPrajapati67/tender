
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.bidderManager.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.bidder-managers.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="supplier_name"><?php echo e(trans('cruds.bidderManager.fields.supplier_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('supplier_name') ? 'is-invalid' : ''); ?>" type="text" name="supplier_name" id="supplier_name" value="<?php echo e(old('supplier_name', '')); ?>" required>
                <?php if($errors->has('supplier_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('supplier_name')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required" for="company_reg_number"><?php echo e(trans('cruds.bidderManager.fields.company_reg_number')); ?></label>
                <input class="form-control <?php echo e($errors->has('company_reg_number') ? 'is-invalid' : ''); ?>" type="text" name="company_reg_number" id="company_reg_number" value="<?php echo e(old('company_reg_number', '')); ?>" required>
                <?php if($errors->has('company_reg_number')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('company_reg_number')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required" for="company_contact_person"><?php echo e(trans('cruds.bidderManager.fields.company_contact_person')); ?></label>
                <input class="form-control <?php echo e($errors->has('company_contact_person') ? 'is-invalid' : ''); ?>" type="text" name="company_contact_person" id="company_contact_person" value="<?php echo e(old('company_contact_person', '')); ?>" required>
                <?php if($errors->has('company_contact_person')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('company_contact_person')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required" for="email"><?php echo e(trans('cruds.bidderManager.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="text" name="email" id="email" value="<?php echo e(old('email', '')); ?>" required>
                <?php if($errors->has('email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required" for="mobile"><?php echo e(trans('cruds.bidderManager.fields.mobile')); ?></label>
                <input class="form-control <?php echo e($errors->has('mobile') ? 'is-invalid' : ''); ?>" type="text" name="mobile" id="mobile" value="<?php echo e(old('mobile', '')); ?>" required>
                <?php if($errors->has('mobile')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('mobile')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required" for="address"><?php echo e(trans('cruds.bidderManager.fields.address')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" name="address" id="address" required><?php echo e(old('address')); ?></textarea>
                <?php if($errors->has('address')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('address')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            
            <div class="form-group">
                <div class="form-check <?php echo e($errors->has('approved') ? 'is-invalid' : ''); ?>">
                    <input type="hidden" name="approved" value="0">
                    <input class="form-check-input" type="checkbox" name="approved" id="approved" value="1" <?php echo e(old('approved', 0) == 1 ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="approved"><?php echo e(trans('cruds.user.fields.approved')); ?></label>
                </div>
                <?php if($errors->has('approved')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('approved')); ?>

                    </div>
                <?php endif; ?>
              
            </div>

            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.bidderManager.fields.status')); ?></label>
                <select class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status" id="status" required>
                    <option value disabled <?php echo e(old('status', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\BidderManager::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status', '1') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\tender\resources\views/admin/bidderManagers/create.blade.php ENDPATH**/ ?>