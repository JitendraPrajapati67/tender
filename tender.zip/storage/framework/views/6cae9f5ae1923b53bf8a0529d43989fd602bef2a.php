
<?php $__env->startSection('content'); ?>


<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.tenderManagement.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.tender-categories.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.tender_reference_no')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->tender_reference_no); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.tender_title')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->tender_title); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.description')); ?>

                        </th>
                        <td>
                             <?php echo e($tender->description?? '-'); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.open_date')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->open_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.close_date')); ?>

                        </th>
                        <td>
                            <?php echo e($tender->close_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.status')); ?>

                        </th>
                        <td>
                            <?php if($tender->status == 0): ?>
                              Inactive
                            <?php else: ?>
                              Active
                            <?php endif; ?>
                            
                        </td>
                    </tr>
                     <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.type')); ?>

                        </th>
                        <td>
                            <?php if($tender->type ==0): ?>
                                Free
                            <?php else: ?>
                                Paid
                            <?php endif; ?>
                            
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tenderManagement.fields.created_by')); ?>

                        </th>
                        <td>
                            <?php if($tender->created_by == 1): ?>
                                Admin
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class='form-group'>
            <label class="" style="margin-left: 25px;">Materials:-</label>  
              <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="" style="margin-left: 25px;"><?php echo e($label->category_name); ?></label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </div>
            <div class='form-group'>
                <?php $__currentLoopData = $tenderMapDocument; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="btn btn-default btn-sm"><i class="fa fa-download"></i> <?php echo e($label->document_orignal_name); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.bidManagement.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-TenderCategory">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bidManagement.fields.id')); ?>

                        </th>
                         <th>
                            <?php echo e(trans('cruds.bidManagement.fields.price')); ?>

                        </th>

                         <th>
                            <?php echo e(trans('cruds.bidManagement.fields.description')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.bidManagement.fields.created_at')); ?>

                        </th>

                        <th>
                            <?php echo e(trans('cruds.bidManagement.fields.updated_at')); ?>

                        </th>
                        <th>
                            Action
                        </th>
      
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($bid->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($bid->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($bid->price ?? '-'); ?>

                            </td>
                            <td>
                                <?php echo e($bid->discription ?? ''); ?>

                            </td>

                            <td>
                               <?php echo e(date('Y-m-d', strtotime($bid->created_at)) ?? ''); ?>

                            </td>

                            <td>
                               <?php echo e(date('Y-m-d', strtotime($bid->updated_at)) ?? ''); ?>

                            </td>

                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tender_category_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('bid.show', $bid->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tender_category_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('bid.edit', $bid->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.tender-categories.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tender\resources\views/admin/tenderManagers/show.blade.php ENDPATH**/ ?>