<?php $__env->startComponent('mail::message'); ?>
    Hello <?php echo e($data['user']['supplier_name']); ?>,
    <br>
    Thank you for choosing <?php echo e(config('app.name')); ?>!

    Click below to tender details <a href="<?php echo e(route('admin.tender.show',$data['tender']['id'])); ?>">Go to your tender</a>

    Sincerely,
    <?php echo e(config('app.name')); ?>.
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\tender\resources\views/email/tenderInvitation.blade.php ENDPATH**/ ?>