<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card mx-4">
            <div class="card-body p-4">
                <h1><?php echo e(trans('panel.site_title')); ?></h1>

                <p class="text-muted">OTP Verification</p>
                <?php echo $__env->make('partials.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <form method="POST" action="<?php echo e(route('auth.otp.verification')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input id="mobile" name="mobile" type="hidden" class="form-control<?php echo e($errors->has('mobile') ? ' is-invalid' : ''); ?>" required autocomplete="mobile" autofocus placeholder="Enter mobile number" value="<?php echo e(old('mobile', $user->mobile)); ?>">

                        <?php if($errors->has('mobile')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('mobile')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-user"></i>
                            </span>
                        </div>
                        <input id="otp" name="otp" type="number" class="form-control<?php echo e($errors->has('otp') ? ' is-invalid' : ''); ?>" required autocomplete="otp" autofocus placeholder="Enter otp" value="<?php echo e(old('otp', null)); ?>">
                        <?php if($errors->has('otp')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('otp')); ?>

                            </div>
                        <?php endif; ?>

                    </div>


                    <div class="row">
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary px-4">
                                Submit
                            </button>
                        </div>
                        <div class="col-6 text-right">
                            <a class="btn btn-link px-0" href="<?php echo e(route('auth.otp.resend',$user->mobile)); ?>">
                                Resend OTP.
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\tender\resources\views/auth/otp/otp.blade.php ENDPATH**/ ?>