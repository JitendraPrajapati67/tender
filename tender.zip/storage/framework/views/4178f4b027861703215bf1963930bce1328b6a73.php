<div id="sidebar" class="c-sidebar c-sidebar-fixed c-sidebar-lg-show">

    <div class="c-sidebar-brand d-md-down-none">
        <a class="c-sidebar-brand-full h4" href="#">
            <?php echo e(trans('panel.site_title')); ?>

        </a>
    </div>

    <ul class="c-sidebar-nav">
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(route("admin.home")); ?>" class="c-sidebar-nav-link">
                <i class="c-sidebar-nav-icon fas fa-fw fa-tachometer-alt">

                </i>
                <?php echo e(trans('global.dashboard')); ?>

            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/permissions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/users*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-users c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.permissions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-unlock-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.permission.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.roles.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-briefcase c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.role.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.users.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.user.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tender_category_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.tender-categories.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/tender-categories") || request()->is("admin/tender-categories/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.tenderCategory.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bidder_manager_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.bidder-managers.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/bidder-managers") || request()->is("admin/bidder-managers/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fab fa-bimobject c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.bidderManager.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if( Auth::user()->id == 1): ?>
        <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/permissions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/users*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-gavel c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.tenderManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.tender.create")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-edit c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.postTender.title')); ?>

                            </a>
                        </li>
                    
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.tender.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-list c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.listTender.title')); ?>

                            </a>
                        </li>
                    <!-- 
                        <li class="c-sidebar-nav-item">
                            <a href="#" class="c-sidebar-nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.biidingMange.title')); ?>

                            </a>
                        </li> -->
                    
                </ul>
            </li>
        <?php else: ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.tender.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-list c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.listTender.title')); ?>

                </a>
            </li>
        <?php endif; ?>


        <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("bid.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("bids") || request()->is("bid/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-dolly-flatbed c-sidebar-nav-icon">

                    </i>
                    <?php if( Auth::user()->id == 1): ?>
                        Tendder Bider
                    <?php else: ?>
                        My <?php echo e(trans('cruds.bidManagement.title')); ?>

                    <?php endif; ?>
                </a>
            </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('material_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.materials.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/materials") || request()->is("admin/materials/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-dolly-flatbed c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.material.title')); ?>

                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_alert_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.user-alerts.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/user-alerts") || request()->is("admin/user-alerts/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-bell c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userAlert.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                <li class="c-sidebar-nav-item">
                    <a class="c-sidebar-nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'c-active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                        <i class="fa-fw fas fa-key c-sidebar-nav-icon">
                        </i>
                        <?php echo e(trans('global.change_password')); ?>

                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
        <li class="c-sidebar-nav-item">
            <a href="#" class="c-sidebar-nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                <i class="c-sidebar-nav-icon fas fa-fw fa-sign-out-alt">

                </i>
                <?php echo e(trans('global.logout')); ?>

            </a>
        </li>
    </ul>

</div>
<?php /**PATH C:\xampp\htdocs\tender\resources\views/partials/menu.blade.php ENDPATH**/ ?>