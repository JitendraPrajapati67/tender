
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.tenderCategory.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.tender-categories.update", [$tenderCategory->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="category_code"><?php echo e(trans('cruds.tenderCategory.fields.category_code')); ?></label>
                <input class="form-control <?php echo e($errors->has('category_code') ? 'is-invalid' : ''); ?>" type="text" name="category_code" id="category_code" value="<?php echo e(old('category_code', $tenderCategory->category_code)); ?>" required>
                <?php if($errors->has('category_code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('category_code')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.tenderCategory.fields.parent_id')); ?></label>
                <select class="form-control <?php echo e($errors->has('parent_id') ? 'is-invalid' : ''); ?>" name="parent_id" id="parent_id" required>
                    <option value disabled <?php echo e(old('parent_id', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = $parentCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($label->id); ?>" <?php echo e(old('parent_id', $tenderCategory->parent_id) === $label->id ? 'selected' : ''); ?>><?php echo e($label->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('parent_id')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('parent_id')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label class="required" for="category_name"><?php echo e(trans('cruds.tenderCategory.fields.category_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('category_name') ? 'is-invalid' : ''); ?>" type="text" name="category_name" id="category_name" value="<?php echo e(old('category_name', $tenderCategory->category_name)); ?>" required>
                <?php if($errors->has('category_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('category_name')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.tenderCategory.fields.description')); ?></label>
                <input class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" type="text" name="description" id="description" value="<?php echo e(old('description', $tenderCategory->description)); ?>">
                <?php if($errors->has('description')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('description')); ?>

                    </div>
                <?php endif; ?>
               
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Vivek_Project\tender\tender25\resources\views/admin/tenderCategories/edit.blade.php ENDPATH**/ ?>