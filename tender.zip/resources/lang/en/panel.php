<?php

return [
    'site_title' => 'Tender Management System',
];